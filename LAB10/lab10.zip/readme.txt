main.cpp contain the code for problem 1, main2.cpp contain the code for problem 2.
I have used armadillo library in this assignment.

For problem 1, I am providing the residual value in file 4.txt,8.txt and 16.txt.
For Problem 2, I am providing the residual value in file 4b.txt,8b.txt and 16b.txt.
Also to plot contour i am using 4bres.txt,8bres.txt and 16bres.txt, which i am also attaching

I have used python noteobook to plot the graphs.

To compile the program i used the command

g++ main.cpp -O2 -larmadillo  && ./a.out
and
g++ main2.cpp -O2 -larmadillo  && ./a.out