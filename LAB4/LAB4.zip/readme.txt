main.cpp has the code for problem 1. This Script Generate two file problem1_result.txt and problem2_result.txt, which contain beta 
and r2 inforamtion for first and second part of problem 1.

main2.cpp contain has the code for problem2. 

The file downloaded from web for problem 2 is data.txt, and i have preprocessed it with python to file data1.txt.
For 2nd problem i m reading from file data1.txt. 