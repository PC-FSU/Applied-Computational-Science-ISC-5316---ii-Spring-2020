Main.cpp contain the c++ code, and LAB11.ipynb contain the python code that
i used for plotting.
I am also incudling the file that i used to generate the plots

"0.txt" and "1.txt" for problem 1.
"h.txt" and "2h.txt" for problem 2.
"a_2h.txt" and "a_h.txt" for problem 3.
"Norm.txt" for jocabi solver for problem 5, part 1
"Norm_2.txt" for grid solver for problem 5, part 2.
