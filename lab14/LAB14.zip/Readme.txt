LAB14.ipynb contain the python script for the lab.
I am also attaching video for Advection, Advection with diffusion to visualize the 
wave evolution with time. If you want to run the animation function you will be needing the
"ffmpeg" Package that you have to install first.