Main.cpp contain the serial code and CRS_Parallel contain the multithread code.
LAB8.IPYNB contain the code for plotting. I am also attaching the file that have been used to 
generate code.
Coords_1000,Coords_5000,Coords_7500,Coords_10000 is used to generate plot for first problem

diff_1,min_1,diff_2,min_2,diff_4,min_4,diff_8,min_8 is used to generate plot for problem 2.