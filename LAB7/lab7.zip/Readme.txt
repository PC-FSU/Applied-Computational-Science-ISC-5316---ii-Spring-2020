I am attaching the main.cpp which contact the c++ code for this lab, and a python notebook
which is used for plotting. I am also attaching text file used to generate the plotes.