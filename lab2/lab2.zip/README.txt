For the first problem, I am generating 1000 random numbers using python, 
So before compiling the c++ code, you need to create "Number_list_1.txt".
I am attaching the notebook that is used to generate this file.
I am providing both copy, Jupyter notebook and .py script, 
but I would recommend using jupyter notebook,
because you will be able to run that particular block that generate "Number_list_1.txt".

Also, I am attaching all the files needed for this exercise (including "Number_list_1.txt").
